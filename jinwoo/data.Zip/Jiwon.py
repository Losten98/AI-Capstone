import hrcalc
ir = []
with open("ir.log", "r") as f:
    for line in f:
        ir.append(int(line))

red = []
with open("red.log", "r") as f:
    for line in f:
        red.append(int(line))

#for i in range(37):
#    print(hrcalc.calc_hr_and_spo2(ir[25*i:25*i+100], red[25*i:25*i+100]))

q = []
p = []

for i in range(37):
    hr,a,spo2,b = hrcalc.calc_hr_and_spo2(ir[25*i:25*i+100], red[25*i:25*i+100])
    q.append(hr)
    p.append(spo2)


with open("./HR.log", "w") as f:
    for r in q:
        f.write("{0}\n".format(r))
        
with open("./SpO2.log", "w") as f:
    for r in p:
        f.write("{0}\n".format(r))
